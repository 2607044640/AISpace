---
inclusion: manual
---
```xml
<critical_rule>
  <rule>MUST explicitly read `KiroWorkingSpace/.kiro/steering/Godot/SceneBuilders/GodotTscnBuilder_Context.md` before proceeding with any UI builder operations.</rule>
  <rule>MUST explicitly read `KiroWorkingSpace/.kiro/steering/Godot/SceneBuilders/GodotTscnBuilder_Context.md` before proceeding with any UI builder operations.</rule>
  <rule>MUST explicitly read `KiroWorkingSpace/.kiro/steering/Godot/SceneBuilders/GodotTscnBuilder_Context.md` before proceeding with any UI builder operations.</rule>
</critical_rule>
<layer_1_quick_start>
  <quick_reference>
    <ul>
      <li>UIModule Location: `KiroWorkingSpace/builder/modules/ui.py`</li>
      <li>Prefabs Directory: `res://A1UIScenes/UIComponents/`</li>
      <li>Gold Standard UI: `res://A1UIScenes/SettingsMenuV2_Fixed.tscn`</li>
      <li>Required MCP Tool: `mcp_godot_get_uid`</li>
      <li>Core Initialization: `ui = UIModule(scene)`</li>
    </ul>
  </quick_reference>
  <decision_tree>
    <ul>
      <li>If building Settings UI -> ALWAYS use UIComponent Prefabs. (Why: Guarantees consistent styling and includes labels).</li>
      <li>If needing a standalone control type with existing prefab (e.g., Dropdown, Slider) -> ALWAYS use Prefab via `add_instance`. (Why: Avoids raw node styling fragmentation).</li>
      <li>If centering UI -> ALWAYS use Fullscreen Control + Margins. (Why: Recommended standard over hardcoded offsets or `CenterContainer`).</li>
    </ul>
  </decision_tree>
  <end_to_end_example>
    <code><![CDATA[
from builder.core import TscnBuilder
from builder.modules.ui import UIModule

# 1. Initialize
scene = TscnBuilder(root_name="SettingsMenu", root_type="Control")
ui = UIModule(scene)

# 2. Setup Base Layout
ui.setup_fullscreen_control()
ui.add_color_rect("Background", parent=".", color=(0.1, 0.1, 0.15, 1), use_anchors=True)
ui.add_margin_container("MainMargin", parent=".", uniform=50)
ui.add_vbox("MainVBox", parent="MainMargin", separation=25)

# 3. Add Raw Controls
ui.add_label("Title", parent="MainVBox", text="Game Settings", align="center", font_size=36)
ui.add_separator("TitleSep", parent="MainVBox")

# 4. Add Prefab Control (Requires UID)
slider_uid = mcp_godot_get_uid(
    projectPath="c:/Godot/3d-practice",
    filePath="A1UIScenes/UIComponents/SliderComponent.tscn"
)["uid"]

ui.add_instance("VolumeSlider", parent="MainVBox",
               scene_path="res://A1UIScenes/UIComponents/SliderComponent.tscn",
               scene_uid=slider_uid)

# 5. Controller Binding
controller_res_id = scene.add_ext_resource("Script", "res://B1Scripts/UI/SettingsController.cs", "uid://controller_uid")
scene.add_node("SettingsController", "Node", parent=".", script=f'ExtResource("{controller_res_id}")')
scene.assign_multiple_node_paths("SettingsController", {"VolumeSlider": "VolumeSlider"})

# 6. Save
scene.save("c:/Godot/3d-practice/Scenes/SettingsMenu.tscn")
]]></code>
  </end_to_end_example>
  <top_anti_patterns>
    <ul>
      <li>Using raw `OptionButton`, `HSlider`, or `CheckBox` directly instead of `UIComponents`. (Why: Bypasses global themes and styling consistency).</li>
      <li>Forgetting to specify `parent="NodeName"` in `ui.add_*` methods. (Why: Results in detached or orphaned nodes).</li>
      <li>Guessing or hardcoding `scene_uid` strings. (Why: Corrupts the Godot scene file reference system).</li>
    </ul>
  </top_anti_patterns>
</layer_1_quick_start>

<layer_2_detailed_guide>
  <api_reference>
    <ul>
      <li>`ui.setup_fullscreen_control(**properties)`</li>
      <li>`ui.add_margin_container(name, parent, uniform=None, left=None, top=None, right=None, bottom=None, script=None, use_anchors=False, vertical_margin=None, horizontal_margin=None)`</li>
      <li>`ui.add_panel_container(name, parent)`</li>
      <li>`ui.add_scroll_container(name, parent, horizontal_scroll=0, vertical_scroll=2, follow_focus=True)`</li>
      <li>`ui.add_vbox(name, parent, separation=None)`</li>
      <li>`ui.add_hbox(name, parent, separation=None)`</li>
      <li>`ui.add_label(name, parent, text="", align="left", font_size=None, min_size=None, size_flags_h=None)`</li>
      <li>`ui.add_button(name, parent, text="", size_flags_h=None)`</li>
      <li>`ui.add_checkbox(name, parent, text="", size_flags_h=None, button_pressed=False)`</li>
      <li>`ui.add_progress_bar(name, parent, value=0, size_flags_h=None, size_flags_v=None, size_flags_stretch_ratio=None, min_size=None, show_percentage=True)`</li>
      <li>`ui.add_color_rect(name, parent, color=(0.15,0.15,0.15,1), use_anchors=False)`</li>
      <li>`ui.add_texture_rect(name, parent, texture_path=None, texture_uid=None, expand_mode=0, stretch_mode=0)`</li>
      <li>`ui.add_separator(name, parent, separation=None, style_path=None, style_uid=None)`</li>
      <li>`ui.add_instance(name, parent, scene_path, scene_uid)`</li>
    </ul>
  </api_reference>
  <implementation_guide>
    <step_1>Initialize `TscnBuilder` and pass it to `UIModule`.</step_1>
    <step_2>Call `ui.setup_fullscreen_control()` to establish a responsive root context.</step_2>
    <step_3>Build container hierarchy using `add_margin_container`, `add_vbox`, and `add_hbox`. ALWAYS pass `parent`.</step_3>
    <step_4>Execute `mcp_godot_get_uid` to retrieve UIDs for ANY required prefabs in `A1UIScenes/UIComponents/`.</step_4>
    <step_5>Inject controls into the hierarchy using `add_instance` (for prefabs) or raw builder methods (for structural layout).</step_5>
    <step_6>Map interactive nodes to C# script properties using `scene.assign_multiple_node_paths`.</step_6>
  </implementation_guide>
  <technical_specifications>
    <table>
      <tr><th>Property/Concept</th><th>Value/Magic Number</th><th>Context</th></tr>
      <tr><td>Fullscreen Root Properties</td><td>`layout_mode = 3`, `anchors_preset = 15`, `anchor_right = 1.0`, `anchor_bottom = 1.0`, `grow_horizontal = 2`, `grow_vertical = 2`</td><td>Generated by `setup_fullscreen_control`</td></tr>
      <tr><td>PanelContainer default</td><td>`layout_mode = 2`</td><td>Added implicitly to panel containers</td></tr>
      <tr><td>Scroll Enums</td><td>`0` = disabled, `1` = auto, `2` = always, `3` = never</td><td>For `horizontal_scroll` and `vertical_scroll`</td></tr>
      <tr><td>Size Flags Enum</td><td>`3` = expand/fill</td><td>Passed to `size_flags_h` or `size_flags_v`</td></tr>
      <tr><td>Color Format</td><td>Tuple: `(R, G, B, A)` scale `0.0 - 1.0`</td><td>`add_color_rect`</td></tr>
      <tr><td>Center Preset Offset</td><td>`layout_mode = 1`, `anchors_preset = 8`</td><td>Alternative preset for centering</td></tr>
    </table>
  </technical_specifications>
  <code_templates>
    <template name="SettingsUI_Prefabs">
      <code><![CDATA[
# Get UIDs for prefabs
dropdown_uid = mcp_godot_get_uid(projectPath="c:/Godot/3d-practice", filePath="A1UIScenes/UIComponents/DropdownComponent.tscn")["uid"]
slider_uid = mcp_godot_get_uid(projectPath="c:/Godot/3d-practice", filePath="A1UIScenes/UIComponents/SliderComponent.tscn")["uid"]
toggle_uid = mcp_godot_get_uid(projectPath="c:/Godot/3d-practice", filePath="A1UIScenes/UIComponents/ToggleComponent.tscn")["uid"]

# Use prefabs
ui.add_instance("ResolutionDropdown", parent="MainVBox",
               scene_path="res://A1UIScenes/UIComponents/DropdownComponent.tscn",
               scene_uid=dropdown_uid)

ui.add_instance("VolumeSlider", parent="MainVBox",
               scene_path="res://A1UIScenes/UIComponents/SliderComponent.tscn",
               scene_uid=slider_uid)

ui.add_instance("FullscreenToggle", parent="MainVBox",
               scene_path="res://A1UIScenes/UIComponents/ToggleComponent.tscn",
               scene_uid=toggle_uid)
]]></code>
    </template>
  </code_templates>
  <core_rules>
    <rule>
      <description>ALWAYS execute `mcp_godot_get_uid` BEFORE calling `ui.add_instance`.</description>
      <rationale>Godot requires accurate `uid://` strings for all external scenes. Omitting this breaks prefab references.</rationale>
      <example>
        # CORRECT
        uid_result = mcp_godot_get_uid(projectPath="...", filePath="...")
        ui.add_instance(..., scene_uid=uid_result["uid"])
      </example>
    </rule>
    <rule>
      <description>NEVER instantiate raw nodes (`OptionButton`, `HSlider`, `CheckBox`) when building Settings UI.</description>
      <rationale>Settings UIs require unified spacing, label associations, and theme connections provided natively by `UIComponents` prefabs.</rationale>
    </rule>
  </core_rules>
</layer_2_detailed_guide>

<layer_3_advanced>
  <troubleshooting>
    <error symptom="UI prefab fails to load with 'Invalid scene UID' error.">
      <cause>The `scene_uid` parameter was hardcoded or guessed instead of retrieved via `mcp_godot_get_uid`.</cause>
      <fix>ALWAYS call `mcp_godot_get_uid(projectPath="c:/Godot/3d-practice", filePath="A1UIScenes/UIComponents/...")` before `ui.add_instance()`. Never hardcode UIDs.</fix>
    </error>
    <error symptom="UI controls appear detached or floating instead of in proper containers.">
      <cause>The `parent` parameter was omitted or incorrect in `ui.add_*()` calls.</cause>
      <fix>ALWAYS specify `parent="NodeName"` for every UI control. Verify hierarchy with `scene.generate_tree_view()` before saving.</fix>
    </error>
    <error symptom="UI layout doesn't center properly or appears off-screen.">
      <cause>Incorrect anchor/margin configuration, or missing `setup_fullscreen_control()` call.</cause>
      <fix>Use Pattern 1 (Fullscreen with Margins): Call `ui.setup_fullscreen_control()` first, then add `MarginContainer` with `uniform=40` or appropriate margins.</fix>
    </error>
    <error symptom="Raw Control nodes (OptionButton, HSlider) don't match project theme.">
      <cause>Using raw nodes instead of UIComponent prefabs.</cause>
      <fix>Check if a prefab exists in `res://A1UIScenes/UIComponents/` for the control type. Use `ui.add_instance()` with the prefab instead of raw `add_button()` or similar methods.</fix>
    </error>
  </troubleshooting>

  <best_practices>
    <rule>
      <description>ALWAYS use Pattern 1 (Fullscreen with Margins) for centering UI layouts.</description>
      <rationale>Provides the most predictable responsive scaling behavior without relying on explicit offsets.</rationale>
      <example>
        # BEFORE (Pattern 2: Explicit Offsets - AVOID)
        scene.initialize_root(layout_mode=1, anchors_preset=8, offset_left=-300, offset_top=-200, offset_right=300, offset_bottom=200)
        
        # AFTER (Pattern 1: Fullscreen Margin Container - REQUIRED)
        ui.setup_fullscreen_control()
        ui.add_margin_container("MainMargin", parent=".", uniform=40)
        ui.add_vbox("MainVBox", parent="MainMargin", separation=20)
      </example>
    </rule>
    <rule>
      <description>ALWAYS use `scene.assign_multiple_node_paths` or `scene.assign_node_path` to bind injected controls to C# Scripts.</description>
      <rationale>UI elements are useless without backend script bindings. The core scene builder handles this logic.</rationale>
    </rule>
    <rule>
      <description>ALWAYS verify prefab availability before building raw controls.</description>
      <rationale>Check `res://A1UIScenes/UIComponents/` directory first. Using prefabs ensures visual consistency and reduces maintenance burden.</rationale>
    </rule>
  </best_practices>

  <common_tasks_quick_index>
    <task name="Build Settings UI with Prefabs">See `<end_to_end_example>` in layer_1_quick_start</task>
    <task name="Get Prefab UID">Use `mcp_godot_get_uid(projectPath="c:/Godot/3d-practice", filePath="A1UIScenes/UIComponents/...")`</task>
    <task name="Center UI Layout">See `<decision_tree>` → "If centering UI" in layer_1_quick_start</task>
    <task name="Add Standard Controls">See `<api_reference>` in layer_2_detailed_guide for all `ui.add_*()` methods</task>
    <task name="Use Prefabs">See `<code_templates>` → "SettingsUI_Prefabs" in layer_2_detailed_guide</task>
  </common_tasks_quick_index>
</layer_3_advanced>
```